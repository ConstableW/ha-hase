"""C1-C4 regression tests, runnable without a Home Assistant installation.

Load the actual source with only external imports replaced by small adapters.
No device, HA service, network request or filesystem write is performed by tests.
"""
import ast
import asyncio
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

ROOT = Path(__file__).resolve().parents[1] / "custom_components" / "code27"


def load_source(name, **adapters):
    tree = ast.parse((ROOT / f"{name}.py").read_text(encoding="utf-8"))
    tree.body = [node for node in tree.body if not (
        isinstance(node, ast.ImportFrom)
        and (node.level or (node.module or "").startswith("homeassistant"))
        or isinstance(node, ast.Import)
        and any(alias.name in {"aiohttp", "yaml", "voluptuous"} for alias in node.names)
    )]
    module = types.ModuleType(f"code27_test_{name}")
    module.__file__ = str(ROOT / f"{name}.py")
    module.__dict__.update(adapters)
    sys.modules[module.__name__] = module
    exec(compile(tree, module.__file__, "exec"), module.__dict__)
    return module


N = types.SimpleNamespace
const = load_source("const")
constants = {key: value for key, value in vars(const).items() if key.isupper()}
api = load_source("api", aiohttp=N(ClientError=OSError))


class CoordinatorBase:
    @classmethod
    def __class_getitem__(cls, item):
        return cls

    def __init__(self, hass, *args, **kwargs):
        self.hass = hass

    def async_update_listeners(self):
        pass


coordinator_module = load_source(
    "coordinator", **constants, DataUpdateCoordinator=CoordinatorBase,
    Code27Error=api.Code27Error, Code27AuthError=api.Code27AuthError,
    Code27ConnectionError=api.Code27ConnectionError,
)
spellbook = load_source("spellbook")
bridge = load_source(
    "bridge", **constants, spellbook=spellbook, callback=lambda f: f,
    PendingCorrection=coordinator_module.PendingCorrection,
    EVENT_USER_MESSAGE=coordinator_module.EVENT_USER_MESSAGE,
    intent=N(IntentResponseType=N(ERROR="error", ACTION_DONE="done")),
)


class DeliveryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.events = []
        self.hass = N(
            config=N(language="de"),
            bus=N(async_fire=lambda kind, data: self.events.append((kind, data))),
            async_create_task=lambda coro, **kwargs: asyncio.create_task(coro),
        )
        self.entry = N(entry_id="device-a", options={
            "bridge_enabled": True, "bridge_codeword": "Computer",
        })
        self.client = N(
            get_chat_history_snapshot=AsyncMock(return_value=("2026-09-09", [])),
            send_chat_text=AsyncMock(return_value="own-1"),
        )
        self.c = coordinator_module.Code27Coordinator(self.hass, self.entry, self.client, 15)
        self.c.data = coordinator_module.Code27Data(current_slot={"slot_number": 1})

    def messages(self, *ids):
        return [{"chat_id": i, "role": "user", "content": f"Computer {i}"} for i in ids]

    async def poll(self, messages):
        self.client.get_chat_history_snapshot.return_value = ("2026-09-09", messages)
        await self.c._async_poll_chat()

    async def test_empty_baseline_then_first_message(self):
        await self.poll([])
        await self.poll(self.messages("first"))
        self.assertEqual([e[1]["chat_id"] for e in self.events], ["first"])

    async def test_burst_delivers_every_message_once(self):
        await self.poll(self.messages("old"))
        messages = self.messages("old", *[str(i) for i in range(50)])
        await self.poll(messages)
        await self.poll(messages)
        self.assertEqual(len(self.events), 50)
        self.assertEqual([e[1]["chat_id"] for e in self.events], [str(i) for i in range(50)])
        self.assertEqual(len(self.c.data.chat_messages), 30)

    async def test_switch_and_return_do_not_replay_inactive_history(self):
        await self.poll(self.messages("a-old"))
        self.c.data.current_slot["slot_number"] = 2
        await self.poll(self.messages("b-old"))
        self.c.data.current_slot["slot_number"] = 1
        await self.poll(self.messages("a-old", "a-inactive"))
        self.assertEqual(self.events, [])
        await self.poll(self.messages("a-old", "a-inactive", "a-new"))
        self.assertEqual(self.events[0][1]["slot"], 1)
        self.assertEqual(self.events[0][1]["chat_id"], "a-new")

    async def test_late_poll_cannot_replace_new_slot(self):
        entered, release = asyncio.Event(), asyncio.Event()

        async def snapshot(*args):
            entered.set()
            await release.wait()
            return "2026-09-09", self.messages("old-slot")

        self.client.get_chat_history_snapshot.side_effect = snapshot
        task = asyncio.create_task(self.c._async_poll_chat())
        await entered.wait()
        self.c.data.current_slot["slot_number"] = 2
        await self.c._async_poll_chat()  # overlapping tick is skipped
        release.set()
        await task
        self.assertEqual(self.c.data.chat_messages, [])
        self.assertEqual(self.client.get_chat_history_snapshot.await_count, 1)

    async def test_own_output_suppressed_but_same_text_from_user_allowed(self):
        await self.poll([])
        text = "Computer Licht aus"
        await self.c.async_send_chat_reply(text, 1)
        await self.poll([
            {"chat_id": "own-1", "role": "user", "content": text},
            {"chat_id": "human", "role": "user", "content": text},
        ])
        self.assertEqual([e[1]["chat_id"] for e in self.events], ["human"])
        self.assertEqual(len(self.c.data.chat_messages), 2)

    async def test_ambiguous_send_suppresses_one_matching_echo(self):
        await self.poll([])
        self.client.send_chat_text.side_effect = api.Code27ConnectionError("timeout")
        with self.assertRaises(api.Code27ConnectionError):
            await self.c.async_send_chat_reply("Computer Licht aus", 1)
        await self.poll([{"chat_id": "accepted", "role": "user", "content": "Computer Licht aus"}])
        self.assertEqual(self.events, [])

    async def test_poll_waits_until_send_id_is_registered(self):
        await self.poll([])
        entered, release = asyncio.Event(), asyncio.Event()

        async def send(*args):
            entered.set()
            await release.wait()
            return "own-1"

        self.client.send_chat_text.side_effect = send
        task = asyncio.create_task(self.c.async_send_chat_reply("Computer own", 1))
        await entered.wait()
        await self.poll(self.messages("own-1"))
        self.assertEqual(self.events, [])
        release.set()
        await task
        await self.poll(self.messages("own-1"))
        self.assertEqual(self.events, [])

    async def test_new_codeword_command_replaces_pending_action(self):
        self.c.pending_correction = coordinator_module.PendingCorrection("Kuche ausschalten", "Kuche")
        forward = AsyncMock(return_value=(None, None, "Buero einschalten"))
        with patch.object(bridge, "_forward_to_assist", forward), patch.object(bridge, "_log_activity"):
            await bridge._handle_bridge_message(
                self.hass, self.entry, self.c, "Computer Buero einschalten", None
            )
        self.assertIsNone(self.c.pending_correction)
        self.assertEqual(forward.call_args.args[3], "Buero einschalten")

    async def test_new_spell_cancels_correction(self):
        self.c.pending_correction = coordinator_module.PendingCorrection("old off", "old")
        self.entry.options["bridge_spellbook"] = "test"
        book = N(name="test")
        match = ("Licht Buero einschalten", None, "lumos", "lumos", True, {})
        with patch.object(spellbook, "async_get_spellbook", AsyncMock(return_value=book)), \
             patch.object(spellbook, "match_spellbook", return_value=match), \
             patch.object(bridge, "_forward_to_assist", AsyncMock(return_value=(None, None, "new"))) as forward, \
             patch.object(bridge, "_log_activity"):
            await bridge._handle_bridge_message(self.hass, self.entry, self.c, "lumos Buero", None)
        self.assertIsNone(self.c.pending_correction)
        self.assertEqual(forward.call_args.args[3], "Licht Buero einschalten")

    async def test_unrelated_sentence_is_not_a_correction_candidate(self):
        self.c.pending_correction = coordinator_module.PendingCorrection("Kuche ausschalten", "Kuche")
        with patch.object(spellbook, "_registry_names", return_value=["Buero"]), \
             patch.object(bridge, "_retry_with_candidate", AsyncMock()) as retry, \
             patch.object(bridge, "_output_speech", AsyncMock()):
            await bridge._handle_correction_reply(self.hass, self.entry, self.c, "Buero einschalten", None)
        retry.assert_not_awaited()

    async def test_name_wrapper_and_abort_still_work(self):
        self.c.pending_correction = coordinator_module.PendingCorrection("Kuche ausschalten", "Kuche")
        with patch.object(spellbook, "_registry_names", return_value=["Buero"]), \
             patch.object(bridge, "_retry_with_candidate", AsyncMock()) as retry:
            await bridge._handle_correction_reply(self.hass, self.entry, self.c, "ich meinte Buero", None)
            retry.assert_awaited_once()
        with patch.object(bridge, "_log_activity"):
            await bridge._handle_correction_reply(self.hass, self.entry, self.c, "Abbruch", None)
        self.assertIsNone(self.c.pending_correction)

    async def test_unload_cancels_ai_before_assist(self):
        entered, cancelled = asyncio.Event(), asyncio.Event()

        async def cleanup(*args):
            entered.set()
            try:
                await asyncio.Event().wait()
            finally:
                cancelled.set()

        with patch.object(bridge, "_ai_cleanup", cleanup), \
             patch.object(bridge, "_ask_assist", AsyncMock()) as assist:
            self.c.async_create_owned_task(
                bridge._forward_to_assist(self.hass, self.entry, self.c, "test", None), "test"
            )
            await entered.wait()
            await self.c.async_stop_realtime()
            self.assertTrue(cancelled.is_set())
            assist.assert_not_awaited()
            await self.c.async_stop_realtime()  # cleanup is idempotent
            self.assertFalse(self.c._owned_tasks)

    async def test_unload_cancels_inflight_poll(self):
        entered = asyncio.Event()

        async def snapshot(*args):
            entered.set()
            await asyncio.Event().wait()

        self.client.get_chat_history_snapshot.side_effect = snapshot
        task = asyncio.create_task(self.c._async_poll_chat())
        await entered.wait()
        await self.c.async_stop_realtime()
        self.assertTrue(task.cancelled())
        self.assertEqual(self.events, [])

    async def test_device_queues_are_independent(self):
        other = coordinator_module.Code27Coordinator(self.hass, N(entry_id="b"), self.client, 15)
        other.data = coordinator_module.Code27Data(current_slot={"slot_number": 1})
        entered, release = asyncio.Event(), asyncio.Event()

        async def handle(hass, entry, coordinator, *args):
            if coordinator is self.c:
                entered.set()
                await release.wait()

        with patch.object(bridge, "_handle_bridge_message", handle):
            task = asyncio.create_task(bridge._process_bridge_message(self.hass, self.entry, self.c, "a", None))
            await entered.wait()
            await asyncio.wait_for(bridge._process_bridge_message(self.hass, self.entry, other, "b", None), 1)
            release.set()
            await task

    async def test_same_device_requests_are_serialized(self):
        entered, release = asyncio.Event(), asyncio.Event()
        calls = []

        async def handle(hass, entry, coordinator, text, entity_id):
            calls.append(text)
            if text == "first":
                entered.set()
                await release.wait()

        with patch.object(bridge, "_handle_bridge_message", handle):
            first = asyncio.create_task(bridge._process_bridge_message(self.hass, self.entry, self.c, "first", None))
            await entered.wait()
            second = asyncio.create_task(bridge._process_bridge_message(self.hass, self.entry, self.c, "second", None))
            await asyncio.sleep(0)
            self.assertEqual(calls, ["first"])
            release.set()
            await asyncio.gather(first, second)
            self.assertEqual(calls, ["first", "second"])

    async def test_event_listener_filters_device_and_tracks_work(self):
        listeners, cleanups = {}, []
        self.entry.async_on_unload = cleanups.append
        self.hass.bus.async_listen = lambda kind, handler: listeners.setdefault(kind, handler) and (lambda: None)
        entered = asyncio.Event()

        async def process(*args):
            entered.set()
            await asyncio.Event().wait()

        with patch.object(bridge, "_bridge_entity_id", return_value=None), \
             patch.object(bridge, "_process_bridge_message", process):
            bridge.async_setup_bridge(self.hass, self.entry, self.c)
            handler = listeners[coordinator_module.EVENT_USER_MESSAGE]
            handler(N(data={"config_entry_id": "other", "text": "Computer test"}))
            self.assertFalse(self.c._owned_tasks)
            handler(N(data={"config_entry_id": "device-a", "text": "Computer test"}))
            await entered.wait()
            self.assertEqual(len(self.c._owned_tasks), 1)
            await self.c.async_stop_realtime()
            handler(N(data={"config_entry_id": "device-a", "text": "Computer test"}))
            self.assertFalse(self.c._owned_tasks)

    async def test_stop_waits_for_websocket_cleanup(self):
        websocket = load_source("websocket_client", **constants)
        ws = websocket.Code27WebSocket(self.hass, self.client)
        entered, cleaned = asyncio.Event(), asyncio.Event()

        async def connection():
            entered.set()
            try:
                await asyncio.Event().wait()
            finally:
                await asyncio.sleep(0)
                cleaned.set()

        ws._task = asyncio.create_task(connection())
        await entered.wait()
        await ws.stop()
        self.assertTrue(cleaned.is_set())
        self.assertIsNone(ws._task)


class ApiTests(unittest.IsolatedAsyncioTestCase):
    async def test_burst_outside_latest_window_recovers_full_day(self):
        client = api.Code27Client(None, "device", 8081)
        client.get_chat_history_dates = AsyncMock(return_value=["2026-09-09"])
        recent = [{"chat_id": str(i)} for i in range(21, 51)]
        full = [{"chat_id": str(i)} for i in range(51)]
        client._call = AsyncMock(side_effect=[{"data": recent}, {"data": full}])
        _, messages = await client.get_chat_history_snapshot(1, "2026-09-09", "0")
        self.assertEqual(len(messages), 51)
        self.assertIn("/chat/history?", client._call.call_args.args[1])

    async def test_midnight_includes_previous_day(self):
        client = api.Code27Client(None, "device", 8081)
        client.get_chat_history_dates = AsyncMock(return_value=["2026-09-09", "2026-09-10"])
        client._call = AsyncMock(side_effect=[{"data": [{"chat_id": "late"}]}, {"data": [{"chat_id": "new"}]}])
        date, messages = await client.get_chat_history_snapshot(1, "2026-09-09", "old")
        self.assertEqual(date, "2026-09-10")
        self.assertEqual([m["chat_id"] for m in messages], ["late", "new"])

    async def test_send_returns_server_message_id(self):
        client = api.Code27Client(None, "device", 8081)
        client._call = AsyncMock(return_value={"success": True, "chat_id": "sent"})
        self.assertEqual(await client.send_chat_text("text", 2), "sent")

    async def test_normal_poll_keeps_small_window(self):
        client = api.Code27Client(None, "device", 8081)
        client.get_chat_history_dates = AsyncMock(return_value=["2026-09-09"])
        client._call = AsyncMock(return_value={"data": [{"chat_id": "old"}, {"chat_id": "new"}]})
        _, messages = await client.get_chat_history_snapshot(1, "2026-09-09", "old")
        self.assertEqual(len(messages), 2)
        client._call.assert_awaited_once()
        self.assertIn("/latest?", client._call.call_args.args[1])

    async def test_initially_empty_history_recovers_multiple_new_days(self):
        client = api.Code27Client(None, "device", 8081)
        client.get_chat_history_dates = AsyncMock(return_value=["2026-09-09", "2026-09-10"])
        client._call = AsyncMock(side_effect=[{"data": [{"chat_id": "first-day"}]}, {"data": [{"chat_id": "second-day"}]}])
        _, messages = await client.get_chat_history_snapshot(1, "")
        self.assertEqual(len(messages), 2)


if __name__ == "__main__":
    unittest.main()

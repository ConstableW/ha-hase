"""Media player for CODE27's built-in music playback."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.media_player import (
    MediaPlayerEntity,
    MediaPlayerEntityFeature,
    MediaPlayerState,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN, MUSIC_SOURCES
from .coordinator import Code27Coordinator
from .entity import Code27Entity

_LOGGER = logging.getLogger(__name__)

_STATUS_MAP = {
    "PLAYING": MediaPlayerState.PLAYING,
    "PAUSED": MediaPlayerState.PAUSED,
    "IDLE": MediaPlayerState.IDLE,
}


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: Code27Coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([Code27MediaPlayer(coordinator)])


class Code27MediaPlayer(Code27Entity, MediaPlayerEntity):
    """The music playback exposed by the CODE27 device."""

    _attr_translation_key = "music"
    _attr_source_list = MUSIC_SOURCES
    _attr_supported_features = (
        MediaPlayerEntityFeature.PLAY
        | MediaPlayerEntityFeature.PAUSE
        | MediaPlayerEntityFeature.NEXT_TRACK
        | MediaPlayerEntityFeature.PREVIOUS_TRACK
        | MediaPlayerEntityFeature.VOLUME_SET
        | MediaPlayerEntityFeature.SELECT_SOURCE
    )

    def __init__(self, coordinator: Code27Coordinator) -> None:
        super().__init__(coordinator)
        machine_id = coordinator.entry.unique_id or coordinator.entry.entry_id
        self._attr_unique_id = f"{machine_id}_music"

    @property
    def state(self) -> MediaPlayerState:
        status = self.coordinator.data.music_playback.get("status", "IDLE")
        return _STATUS_MAP.get(status, MediaPlayerState.IDLE)

    @property
    def media_title(self) -> str | None:
        return self.coordinator.data.music_playback.get("track_name") or None

    @property
    def media_duration(self) -> int | None:
        duration_ms = self.coordinator.data.music_playback.get("duration_ms")
        return int(duration_ms / 1000) if duration_ms else None

    @property
    def media_position(self) -> int | None:
        position_ms = self.coordinator.data.music_playback.get("position_ms")
        return int(position_ms / 1000) if position_ms is not None else None

    @property
    def volume_level(self) -> float | None:
        playback = self.coordinator.data.music_playback
        volume = playback.get("volume_level")
        volume_max = playback.get("volume_max") or 100
        if volume is None:
            return None
        return volume / volume_max

    @property
    def source(self) -> str | None:
        return self.coordinator.data.music_source.get("source")

    async def async_media_play(self) -> None:
        await self.coordinator.client.music_control("PLAY")
        await self.coordinator.async_request_refresh()

    async def async_media_pause(self) -> None:
        await self.coordinator.client.music_control("PAUSE")
        await self.coordinator.async_request_refresh()

    async def async_media_next_track(self) -> None:
        await self.coordinator.client.music_control("NEXT")
        await self.coordinator.async_request_refresh()

    async def async_media_previous_track(self) -> None:
        await self.coordinator.client.music_control("PREVIOUS")
        await self.coordinator.async_request_refresh()

    async def async_set_volume_level(self, volume: float) -> None:
        await self.coordinator.client.music_control(
            "SET_VOLUME", volume_level=round(volume * 100)
        )
        await self.coordinator.async_request_refresh()

    async def async_select_source(self, source: str) -> None:
        await self.coordinator.client.set_music_source(source)
        await self.coordinator.async_request_refresh()

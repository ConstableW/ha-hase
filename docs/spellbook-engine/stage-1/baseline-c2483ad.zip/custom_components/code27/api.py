"""Lightweight async client for the CODE27 (CODIE) local HTTP API.

The device exposes a Vue single-page app at ``http://<host>:8081`` which talks
to a local REST API under ``/v1/api``. Requests (other than the three auth
bootstrap/pairing endpoints) must be signed with an HMAC-SHA256 signature
derived from a per-installation secret that is handed out during a one-time
"pairing" flow (a 6-digit code is shown on the device's own screen).

This module re-implements that signing scheme exactly as the web app does it
(reverse engineered from the served JS bundle), so Home Assistant can act as
just another paired "browser" without needing anything CODE27 doesn't already
provide.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import random
import string
import time
from typing import Any
from urllib.parse import quote

import aiohttp

_LOGGER = logging.getLogger(__name__)

_NONCE_ALPHABET = string.digits + string.ascii_lowercase
_UNSIGNED_PATHS = ("/auth/bootstrap", "/auth/pair/request", "/auth/pair/confirm")


class Code27Error(Exception):
    """Generic error talking to the CODE27 device."""


class Code27AuthError(Code27Error):
    """Raised when the stored pairing credentials are no longer valid."""

    def __init__(self, code: str | None = None) -> None:
        super().__init__(code or "auth_error")
        self.code = code


class Code27ConnectionError(Code27Error):
    """Raised when the device cannot be reached."""


def _sha256_hex(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _hmac_sha256_hex(secret: str, message: str) -> str:
    return hmac.new(secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).hexdigest()


def _nonce() -> str:
    return "".join(random.choice(_NONCE_ALPHABET) for _ in range(16))


class Code27Client:
    """Talks to a single CODE27 device over the local LAN."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        host: str,
        port: int,
        user_id: str | None = None,
        local_secret: str | None = None,
    ) -> None:
        self._session = session
        self.host = host
        self.port = port
        self.user_id = user_id
        self.local_secret = local_secret

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    # -- auth / pairing -----------------------------------------------

    async def bootstrap(self) -> dict[str, Any]:
        """Public, unauthenticated info about the device."""
        return await self._call("GET", "/auth/bootstrap", signed=False)

    async def pair_request(self) -> str:
        """Ask the device to show a 6-digit pairing code on its screen.

        Returns the challenge_id that must be passed back to pair_confirm.
        """
        result = await self._call("POST", "/auth/pair/request", signed=False)
        challenge_id = (result.get("data") or {}).get("challenge_id")
        if not challenge_id:
            raise Code27Error("pairing_no_challenge")
        return challenge_id

    async def pair_confirm(self, pairing_code: str, challenge_id: str) -> tuple[str, str]:
        """Exchange a pairing code for permanent local credentials.

        Returns (user_id, local_secret).
        """
        result = await self._call(
            "POST",
            "/auth/pair/confirm",
            body={"pairing_code": pairing_code, "challenge_id": challenge_id},
            signed=False,
        )
        data = result.get("data") or {}
        secret = data.get("local_secret")
        if not secret:
            raise Code27Error("pairing_no_secret")
        # The bootstrap user_id is the one used for signing, not any id echoed here.
        if not self.user_id:
            boot = await self.bootstrap()
            self.user_id = (boot.get("data") or {}).get("user_id")
        self.local_secret = secret
        return self.user_id or "", secret

    # -- system ----------------------------------------------------------

    async def get_system(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/system")).get("data", {})

    # -- music -------------------------------------------------------------

    async def get_music_page(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/music/page")).get("data", {})

    async def get_music_source(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/music/source")).get("data", {})

    async def set_music_source(self, source: str) -> None:
        await self._call(
            "POST",
            "/data/user/music/source",
            body={"source": source, "request_id": f"ha-{int(time.time() * 1000)}"},
        )

    async def get_music_playback(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/music/playback")).get("data", {})

    async def get_music_audio_route(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/music/audio-route")).get("data", {})

    async def get_bluetooth_state(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/music/bluetooth")).get("data", {})

    async def music_control(self, action: str, **extra: Any) -> None:
        body = {
            "action": action,
            "source": "LOCAL_TF",
            "request_id": f"ha-{int(time.time() * 1000)}",
            **extra,
        }
        await self._call("POST", "/data/user/music/control", body=body)

    # -- lights ------------------------------------------------------------

    async def get_light_master_switch(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/light-master-switch")).get("data", {})

    async def set_light_master_switch(self, enabled: bool) -> None:
        await self._call("POST", "/data/user/light-master-switch", body={"enabled": enabled})

    async def list_light_projects(self) -> list[dict[str, Any]]:
        return (await self._call("GET", "/data/user/light-projects")).get("data", [])

    async def get_applied_light_project(self) -> dict[str, Any]:
        return (await self._call("GET", "/data/user/light-projects/applied")).get("data", {})

    async def apply_light_project(self, project_id: str) -> None:
        await self._call("POST", f"/data/user/light-projects/{project_id}/apply")

    # -- alarms --------------------------------------------------------------

    async def list_alarms(self) -> list[dict[str, Any]]:
        return (await self._call("GET", "/data/user/alarm/list")).get("data", [])

    async def create_alarm(self, alarm: dict[str, Any]) -> dict[str, Any]:
        return (await self._call("POST", "/data/user/alarm", body={"alarm": alarm})).get("data", {})

    async def update_alarm(self, alarm_id: str, alarm: dict[str, Any]) -> dict[str, Any]:
        return (
            await self._call("PUT", f"/data/user/alarm/{alarm_id}", body={"alarm": alarm})
        ).get("data", {})

    async def delete_alarm(self, alarm_id: str) -> None:
        await self._call("DELETE", f"/data/user/alarm/{alarm_id}")

    async def enable_alarm(self, alarm_id: str) -> None:
        await self._call("POST", f"/data/user/alarm/{alarm_id}/enable")

    async def disable_alarm(self, alarm_id: str) -> None:
        await self._call("POST", f"/data/user/alarm/{alarm_id}/disable")

    # -- memos (notes & reminders) ------------------------------------------

    async def list_memos(self) -> list[dict[str, Any]]:
        return (await self._call("GET", "/data/user/memos")).get("data", [])

    async def create_memo(self, memo: dict[str, Any]) -> dict[str, Any]:
        return (await self._call("POST", "/data/user/memos", body={"memo": memo})).get("data", {})

    async def update_memo(self, memo_id: str, memo: dict[str, Any]) -> dict[str, Any]:
        return (
            await self._call("PUT", f"/data/user/memos/{memo_id}", body={"memo": memo})
        ).get("data", {})

    async def delete_memo(self, memo_id: str) -> None:
        await self._call("DELETE", f"/data/user/memos/{memo_id}")

    # -- character -----------------------------------------------------------

    async def list_character_settings(self) -> list[dict[str, Any]]:
        return (await self._call("GET", "/data/user/character/list")).get("data", [])

    async def get_current_slot(self, scope: str = "chat") -> dict[str, Any]:
        return (await self._call("GET", f"/data/user/slot?scope={scope}")).get("data", {})

    async def update_selected_slot(self, slot_number: int, scope: str = "chat") -> None:
        await self._call(
            "PUT", "/data/user/slot", body={"slot_number": slot_number, "scope": scope}
        )

    # -- chat ------------------------------------------------------------------

    async def get_chat_history_dates(self, slot: int = 1) -> list[str]:
        return (
            await self._call("GET", f"/data/user/chat/history/dates?slot={slot}")
        ).get("data", [])

    async def get_latest_chat_messages(
        self, slot: int = 1, limit: int = 10
    ) -> list[dict[str, Any]]:
        """The most recent messages (both roles) for a character slot.

        Chronological order (oldest first, like the API returns them).
        """
        dates = await self.get_chat_history_dates(slot)
        if not dates:
            return []
        latest_date = max(dates)
        result = await self._call(
            "GET",
            f"/data/user/chat/history/latest?date={latest_date}&slot={slot}&limit={limit}",
        )
        return result.get("data", [])

    async def get_chat_history_snapshot(
        self, slot: int, since_date: str | None = None, after_chat_id: str | None = None
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Read complete days, including the previous poll's day at midnight.

        The bounded latest endpoint is unsuitable for command delivery: a
        burst of messages can move unseen commands outside its window.
        """
        dates = sorted(await self.get_chat_history_dates(slot))
        if not dates:
            return since_date, []
        if since_date == dates[-1] and after_chat_id is not None:
            recent = await self._call(
                "GET",
                f"/data/user/chat/history/latest?date={dates[-1]}&slot={slot}&limit=30",
            )
            messages = recent.get("data", [])
            if any(str(m.get("chat_id")) == after_chat_id for m in messages):
                return dates[-1], sorted(messages, key=lambda m: str(m.get("created_at") or ""))
        selected = [date for date in dates if date >= (dates[-1] if since_date is None else since_date)]
        messages = []
        for date in selected:
            result = await self._call(
                "GET", f"/data/user/chat/history?date={date}&slot={slot}"
            )
            messages.extend(result.get("data", []))
        return dates[-1], sorted(messages, key=lambda m: str(m.get("created_at") or ""))

    async def send_chat_text(self, text: str, slot: int = 1) -> str | None:
        result = await self._call(
            "POST", "/data/user/chat/text", body={"text": text, "slot": slot}
        )
        chat_id = result.get("chat_id")
        return str(chat_id) if chat_id is not None else None

    # -- text-to-speech audition (also usable as a plain announcement) --------

    async def tts_audition(self, voice_id: str, text: str, group_key: str) -> None:
        """Speak arbitrary text through the device using a character's voice.

        This is the same endpoint the web UI's Voice settings "PREVIEW"
        button uses, just with a caller-supplied ``text`` instead of the
        UI's fixed preview sentence - the API itself doesn't restrict it.
        """
        await self._call(
            "POST",
            "/data/user/tts_audition",
            body={"voice_id": voice_id, "text": text, "group_key": group_key},
        )

    async def get_tts_audition_state(self) -> dict[str, Any]:
        """Current playback state: STARTING/WAITING/PLAYING/ENDED/FAILED."""
        return (await self._call("GET", "/data/user/tts_audition/state")).get("data", {})

    # -- light preview (ad-hoc solid color / simple effects) -------------------

    async def preview_light_color(
        self,
        red: int,
        green: int,
        blue: int,
        brightness: int = 220,
        effect: str = "STATIC",
        led_count: int = 17,
    ) -> None:
        """Render a single-color procedural layer via the (non-persisted) preview
        channel the Light Editor itself uses while designing a project.

        This never touches any saved light project; it's the same mechanism
        the device's own "preview" button in Lab -> Light Editor uses.
        """
        project = {
            "projectId": "ha_preview",
            "name": "Home Assistant",
            "version": 2,
            "mode": "normal",
            "ledCount": led_count,
            "durationMs": 3000,
            "segments": [
                {
                    "segmentId": "ha_segment",
                    "startMs": 0,
                    "durationMs": 3000,
                    "layers": [
                        {
                            "layerId": "ha_layer",
                            "owner": "ha_layer",
                            "kind": "procedural",
                            "ledRange": {"start": 0, "endInclusive": led_count - 1},
                            "enabled": True,
                            "priority": "primary",
                            "type": effect,
                            "brightness": brightness,
                            "speed": 60,
                            "primaryColor": {"r": red, "g": green, "b": blue},
                            "secondaryColor": {"r": 0, "g": 0, "b": 0},
                        }
                    ],
                }
            ],
            "normal": {},
            "reactive": {},
            "updatedAt": 1,
        }
        await self._call(
            "POST", "/data/user/light-projects/preview", body={"project": project}
        )

    async def stop_light_preview(self) -> None:
        await self._call("POST", "/data/user/light-projects/preview/stop")

    # -- misc ------------------------------------------------------------------

    async def play_sound(self) -> None:
        await self._call("POST", "/data/user/sound/play")

    async def stop_sound(self) -> None:
        await self._call("POST", "/data/user/sound/stop")

    # -- realtime (WebSocket) ---------------------------------------------

    async def build_ws_url(self) -> str:
        """A freshly-signed URL for the device's push-update WebSocket.

        Same HMAC scheme as REST calls, just passed as query parameters
        since a WebSocket handshake can't carry custom headers - exactly how
        the device's own web UI authenticates its live channel.
        """
        if not self.local_secret or not self.user_id:
            raise Code27AuthError("not_paired")

        path = "/v1/ws/channel"
        timestamp = str(int(time.time()))
        nonce = _nonce()
        body_hash = _sha256_hex("")

        canonical = "|".join(
            ["GET", path, timestamp, nonce, "empty", body_hash, self.user_id]
        )
        signature = _hmac_sha256_hex(self.local_secret, canonical)

        params = {
            "sig": signature,
            "nonce": nonce,
            "timestamp": timestamp,
            "payload_mode": "empty",
            "body_hash": body_hash,
            "user_id": self.user_id,
        }
        query = "&".join(f"{k}={quote(str(v), safe='')}" for k, v in params.items())
        return f"ws://{self.host}:{self.port}{path}?{query}"

    # -- low level ---------------------------------------------------------

    def _sign(
        self, method: str, path: str, body_str: str | None
    ) -> dict[str, str]:
        if not self.local_secret or not self.user_id:
            raise Code27AuthError("not_paired")

        url = ("/v1/api" + path).split("?", 1)[0]
        while "//" in url:
            url = url.replace("//", "/")

        timestamp = str(int(time.time()))
        nonce = _nonce()

        if body_str is None:
            payload_mode = "empty"
            body_hash = _sha256_hex("")
        else:
            payload_mode = "json"
            body_hash = _sha256_hex(body_str)

        canonical = "|".join(
            [method.upper(), url, timestamp, nonce, payload_mode, body_hash, self.user_id]
        )
        signature = _hmac_sha256_hex(self.local_secret, canonical)

        return {
            "X-Local-Sig": signature,
            "X-Local-Nonce": nonce,
            "X-Local-Timestamp": timestamp,
            "X-Local-Payload-Mode": payload_mode,
            "X-Local-Body-Hash": body_hash,
            "X-Local-User-Id": self.user_id,
        }

    async def _call(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        signed: bool = True,
        timeout: float = 10.0,
    ) -> dict[str, Any]:
        url = self.base_url + "/v1/api" + path
        headers = {"Accept": "application/json"}

        # Sign (and later send) the *exact* same bytes: the server recomputes
        # the body hash from what it actually receives on the wire, so the
        # hash we sign has to match byte-for-byte, not just semantically.
        body_str: str | None = None
        if body is not None:
            body_str = json.dumps(body, separators=(",", ":"))
            headers["Content-Type"] = "application/json"

        if signed and not any(path.startswith(p) for p in _UNSIGNED_PATHS):
            headers.update(self._sign(method, path, body_str))

        try:
            async with asyncio.timeout(timeout):
                resp = await self._session.request(
                    method,
                    url,
                    data=body_str.encode("utf-8") if body_str is not None else None,
                    headers=headers,
                )
                text = await resp.text()
        except (aiohttp.ClientError, asyncio.TimeoutError) as err:
            raise Code27ConnectionError(str(err)) from err

        try:
            data = json.loads(text) if text else {}
        except ValueError as err:
            if resp.status == 401:
                raise Code27AuthError() from err
            raise Code27Error(f"invalid_response: http_{resp.status}") from err
        if resp.status == 401:
            code = data.get("code") if isinstance(data, dict) else None
            raise Code27AuthError(code if isinstance(code, str) else None)
        if not isinstance(data, dict):
            raise Code27Error("invalid_response: expected object envelope")
        if resp.status >= 400 or data.get("success") is False:
            raise Code27Error(data.get("message") or data.get("code") or f"http_{resp.status}")
        self._validate_response_data(method, path, data)
        return data

    _MUSIC_PATHS = {
        "/data/user/music/page", "/data/user/music/source",
        "/data/user/music/playback", "/data/user/music/audio-route",
    }

    @staticmethod
    def _validate_response_data(method: str, path: str, response: dict) -> None:
        """Validate the resource shapes consumed by our typed wrappers."""
        path = path.split("?", 1)[0]
        if method != "GET" and "data" not in response:
            return  # write acknowledgements may have no data (including 204)
        value = response.get("data")
        list_paths = {
            "/data/user/character/list", "/data/user/alarm/list", "/data/user/memos",
            "/data/user/light-projects", "/data/user/chat/history",
            "/data/user/chat/history/latest", "/data/user/chat/history/dates",
        }
        expect_list = method == "GET" and path in list_paths
        if not isinstance(value, list if expect_list else dict):
            raise Code27Error(f"invalid_response: unexpected data shape for {path}")
        if expect_list:
            if path.endswith("/dates"):
                if not all(isinstance(item, str) for item in value):
                    raise Code27Error("invalid_response: expected date strings")
            elif not all(isinstance(item, dict) for item in value):
                raise Code27Error("invalid_response: expected object list")
            if path in {"/data/user/alarm/list", "/data/user/memos", "/data/user/light-projects"}:
                if any(not isinstance(item.get("id"), str) or not item["id"] for item in value):
                    raise Code27Error("invalid_response: missing resource id")
        objects = value if expect_list and not path.endswith("/dates") else [value]
        # "version" means two different things depending on the endpoint:
        # a numeric revision counter on the music/* endpoints (what
        # _music_is_older compares), but a firmware version *string* on
        # /data/user/system - same JSON key, unrelated meaning. Only
        # enforce the numeric shape where it's actually used numerically.
        numeric_keys = ["slot_number", "hour", "minute", "ledCount", "next_fire_at_ms",
                         "updated_at_ms"]
        if path in Code27Client._MUSIC_PATHS:
            numeric_keys.append("version")
        for obj in objects:
            if not isinstance(obj, dict):
                continue
            for key in numeric_keys:
                if key in obj and (not isinstance(obj[key], (int, float)) or isinstance(obj[key], bool)):
                    raise Code27Error(f"invalid_response: invalid {key}")
            for key in ("machine_id", "user_id", "challenge_id", "local_secret", "name",
                        "content", "role", "voice_id", "group_key", "ai_language", "state"):
                if key in obj and obj[key] is not None and not isinstance(obj[key], str):
                    raise Code27Error(f"invalid_response: invalid {key}")

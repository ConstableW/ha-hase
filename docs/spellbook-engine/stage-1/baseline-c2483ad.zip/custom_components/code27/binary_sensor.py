"""Binary sensors for CODE27."""
from __future__ import annotations

from typing import Any

from homeassistant.components.binary_sensor import BinarySensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import Code27Coordinator
from .entity import Code27Entity


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    coordinator: Code27Coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [
            Code27MusicModeBinarySensor(coordinator),
            Code27NotificationActiveBinarySensor(coordinator),
        ]
    )


class Code27MusicModeBinarySensor(Code27Entity, BinarySensorEntity):
    """Whether the music page is currently open on the device screen."""

    _attr_translation_key = "music_mode_active"

    def __init__(self, coordinator: Code27Coordinator) -> None:
        super().__init__(coordinator)
        machine_id = coordinator.entry.unique_id or coordinator.entry.entry_id
        self._attr_unique_id = f"{machine_id}_music_mode_active"

    @property
    def is_on(self) -> bool:
        return bool(self.coordinator.data.music_page.get("is_open"))


class Code27NotificationActiveBinarySensor(Code27Entity, BinarySensorEntity):
    """Whether a "Hinweis" notification is currently blinking the LEDs.

    Triggered via the code27.notify service (e.g. from Node-RED) and cleared
    either by the matching code27.notify_clear call or the "Hinweis
    quittieren" button. CODE27 has no such concept itself - this is purely
    tracked on the Home Assistant side.
    """

    _attr_translation_key = "notification_active"

    def __init__(self, coordinator: Code27Coordinator) -> None:
        super().__init__(coordinator)
        machine_id = coordinator.entry.unique_id or coordinator.entry.entry_id
        self._attr_unique_id = f"{machine_id}_notification_active"

    @property
    def is_on(self) -> bool:
        return self.coordinator.notification_active

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {
            "message": self.coordinator.notification_message,
            "color": self.coordinator.notification_color,
        }

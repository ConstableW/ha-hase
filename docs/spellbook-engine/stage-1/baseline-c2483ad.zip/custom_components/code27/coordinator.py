"""Data update coordinator for CODE27.

Two update paths run side by side:
- A slow full poll (DataUpdateCoordinator's normal interval) that covers
  everything, including fields with no push equivalent (alarms, memos,
  system, light projects, character slots) - the reliable fallback.
- A realtime path: the device's own WebSocket channel pushes music/light-page
  state instantly (see websocket_client.py), and chat messages are polled
  separately on a much shorter interval than the main scan_interval, since
  CODE27 has no push event for new chat messages at all.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import Code27AuthError, Code27Client, Code27ConnectionError, Code27Error
from .const import (
    DEFAULT_AMBIENT_BRIGHTNESS,
    DEFAULT_AMBIENT_RGB,
    DOMAIN,
    LIGHT_EFFECT_STATIC,
    LIGHT_EFFECT_TO_TYPE,
)
from .websocket_client import Code27WebSocket

_LOGGER = logging.getLogger(__name__)

EVENT_USER_MESSAGE = f"{DOMAIN}_user_message"
EVENT_ASSISTANT_MESSAGE = f"{DOMAIN}_assistant_message"

CHAT_POLL_INTERVAL = timedelta(seconds=3)


@dataclass
class Code27Data:
    """Snapshot of everything the integration polls."""

    system: dict[str, Any] = field(default_factory=dict)
    music_page: dict[str, Any] = field(default_factory=dict)
    music_source: dict[str, Any] = field(default_factory=dict)
    music_playback: dict[str, Any] = field(default_factory=dict)
    music_audio_route: dict[str, Any] = field(default_factory=dict)
    light_master_switch: dict[str, Any] = field(default_factory=dict)
    light_projects: list[dict[str, Any]] = field(default_factory=list)
    applied_light_project: dict[str, Any] = field(default_factory=dict)
    alarms: list[dict[str, Any]] = field(default_factory=list)
    memos: list[dict[str, Any]] = field(default_factory=list)
    character_slots: list[dict[str, Any]] = field(default_factory=list)
    current_slot: dict[str, Any] = field(default_factory=dict)
    last_user_message: dict[str, Any] = field(default_factory=dict)
    last_assistant_message: dict[str, Any] = field(default_factory=dict)
    chat_messages: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class PendingCorrection:
    """An open "Meintest du...?" entity-correction dialog for this
    device's Assist bridge (see bridge.py). Lives only in memory on the
    coordinator - lost on reload/restart, which is fine, a stale
    multi-turn dialog shouldn't survive that anyway. At most one open
    dialog per device at a time."""

    original_command: str
    failed_phrase: str
    tried_candidates: list[str] = field(default_factory=list)
    last_suggested: str | None = None
    catchphrase: str | None = None
    include_areas: bool = False
    entity_id: str | None = None
    slot: int | None = None
    language: str | None = None
    created_at: float = field(default_factory=time.monotonic)
    # Set instead of the fields above when this dialog is a spellbook
    # "which one did you mean" choice (see bridge.py's
    # _begin_spell_choice_correction) rather than an entity/area name
    # correction - each is (resolved_command, catchphrase, trigger_text).
    spell_option_a: tuple[str, str | None, str] | None = None
    spell_option_b: tuple[str, str | None, str] | None = None

    def is_expired(self, timeout_seconds: float) -> bool:
        return time.monotonic() - self.created_at > timeout_seconds

    def touch(self) -> None:
        """Reset the idle timer - called on every reply the dialog
        actually consumes, even one that didn't resolve to a candidate,
        since replying at all means the user is still engaged."""
        self.created_at = time.monotonic()


class Code27Coordinator(DataUpdateCoordinator[Code27Data]):
    """Polls the CODE27 device on a fixed interval, plus realtime push."""

    def __init__(
        self, hass: HomeAssistant, entry: ConfigEntry, client: Code27Client, scan_interval: int
    ) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name="CODE27",
            update_interval=timedelta(seconds=scan_interval),
        )
        self.entry = entry
        self.client = client
        self.pending_correction: PendingCorrection | None = None
        self._chat_seen: dict[int, set[str]] = {}
        self._chat_dates: dict[int, str | None] = {}
        self._chat_last_ids: dict[int, str | None] = {}
        self._chat_active_slot: int | None = None
        self._chat_lock = asyncio.Lock()
        self.bridge_lock = asyncio.Lock()
        self._notification_lock = asyncio.Lock()
        self._music_revisions: dict[str, int] = {}
        self._owned_tasks: set[asyncio.Task] = set()
        self._poll_task: asyncio.Task | None = None
        self.stopping = False
        self._own_chat_ids: set[tuple[int, str]] = set()
        self._pending_chat_replies: list[tuple[int, str]] = []
        self._websocket: Code27WebSocket | None = None
        self._chat_poll_unsub: Any = None

        # Notification ("Hinweis") state: CODE27 has no concept of this
        # itself, it's purely something we layer on top using the same LED
        # preview mechanism the "Umgebungsfarbe" light uses.
        self.notification_active: bool = False
        self.notification_message: str | None = None
        self.notification_color: tuple[int, int, int] = (255, 0, 0)
        self._pre_notification_light_enabled: bool | None = None

        # What HA itself last asked the ambient-light preview channel to
        # show - CODE27 has no readback for that, so this is the only
        # record of it, shared with light.py so a notification's blink can
        # restore it afterwards instead of just stopping.
        self.ambient_rgb_color: tuple[int, int, int] = DEFAULT_AMBIENT_RGB
        self.ambient_brightness: int = DEFAULT_AMBIENT_BRIGHTNESS
        self.ambient_effect: str = LIGHT_EFFECT_STATIC

    def _led_count(self) -> int:
        for project in self.data.light_projects if self.data else []:
            if project.get("ledCount"):
                return int(project["ledCount"])
        return 17

    async def async_trigger_notification(
        self, message: str | None, color: tuple[int, int, int]
    ) -> None:
        async with self._notification_lock:
            was_enabled = self._pre_notification_light_enabled
            if was_enabled is None:
                was_enabled = bool(self.data and self.data.light_master_switch.get("enabled"))
                # Preserve the original state even if a later write fails.
                self._pre_notification_light_enabled = was_enabled
            if self.data and not self.data.light_master_switch.get("enabled"):
                await self.client.set_light_master_switch(True)
            red, green, blue = color
            await self.client.preview_light_color(
                red, green, blue, brightness=255, effect="BLINK", led_count=self._led_count()
            )
            self.notification_active = True
            self.notification_message = message
            self.notification_color = color
            self.async_update_listeners()

    async def async_acknowledge_notification(self) -> None:
        """Commit local acknowledgement only after restoration succeeds."""
        async with self._notification_lock:
            if not self.notification_active and self._pre_notification_light_enabled is None:
                return
            if self._pre_notification_light_enabled:
                red, green, blue = self.ambient_rgb_color
                await self.client.preview_light_color(
                    red, green, blue, brightness=self.ambient_brightness,
                    effect=LIGHT_EFFECT_TO_TYPE[self.ambient_effect], led_count=self._led_count(),
                )
            else:
                await self.client.stop_light_preview()
                await self.client.set_light_master_switch(False)
            self.notification_active = False
            self.notification_message = None
            self._pre_notification_light_enabled = None
            self.async_update_listeners()

    async def _async_update_data(self) -> Code27Data:
        revisions = dict(self._music_revisions)
        try:
            (
                system,
                music_page,
                music_source,
                music_playback,
                music_audio_route,
                light_master_switch,
                light_projects,
                applied_light_project,
                alarms,
                memos,
                character_slots,
                current_slot,
            ) = await asyncio.gather(
                self.client.get_system(),
                self.client.get_music_page(),
                self.client.get_music_source(),
                self.client.get_music_playback(),
                self.client.get_music_audio_route(),
                self.client.get_light_master_switch(),
                self.client.list_light_projects(),
                self.client.get_applied_light_project(),
                self.client.list_alarms(),
                self.client.list_memos(),
                self.client.list_character_settings(),
                self.client.get_current_slot(),
            )
        except Code27AuthError as err:
            raise ConfigEntryAuthFailed(err.code or "auth_error") from err
        except Code27ConnectionError as err:
            raise UpdateFailed(f"Cannot reach CODE27 device: {err}") from err
        except Code27Error as err:
            raise UpdateFailed(str(err)) from err

        # Chat is polled on its own, much faster, timer - reuse whatever it
        # last saw instead of re-fetching (or wiping!) it here too.
        last_user_message = self.data.last_user_message if self.data else {}
        last_assistant_message = self.data.last_assistant_message if self.data else {}
        chat_messages = self.data.chat_messages if self.data else []

        snapshot = Code27Data(
            system=system,
            music_page=music_page,
            music_source=music_source,
            music_playback=music_playback,
            music_audio_route=music_audio_route,
            light_master_switch=light_master_switch,
            light_projects=light_projects,
            applied_light_project=applied_light_project,
            alarms=alarms,
            memos=memos,
            character_slots=character_slots,
            current_slot=current_slot,
            last_user_message=last_user_message,
            last_assistant_message=last_assistant_message,
            chat_messages=chat_messages,
        )
        if self.data:
            for field in ("music_page", "music_source", "music_playback", "music_audio_route"):
                current = getattr(self.data, field)
                incoming = getattr(snapshot, field)
                if (self._music_revisions.get(field, 0) != revisions.get(field, 0)
                        or self._music_is_older(incoming, current)):
                    setattr(snapshot, field, current)
        return snapshot

    @staticmethod
    def _music_is_older(incoming: dict, current: dict) -> bool:
        # Prefer timestamps so a newer state can reset the version counter.
        for key in ("updated_at_ms", "version"):
            left, right = incoming.get(key), current.get(key)
            if isinstance(left, (int, float)) and isinstance(right, (int, float)):
                if left != right:
                    return left < right
        return False

    def _handle_music_push(self, field: str, data: dict) -> None:
        if not self.data or self.stopping or not isinstance(data, dict):
            return
        current = getattr(self.data, field)
        if data == current or self._music_is_older(data, current):
            return
        setattr(self.data, field, data)
        self._music_revisions[field] = self._music_revisions.get(field, 0) + 1
        # A partial push neither reschedules the full poll nor repairs its
        # error state (alarms/memos/system may still be unreachable).
        self.async_update_listeners()

    # -- realtime: WebSocket push for music/light-page state -----------------

    def async_start_realtime(self) -> None:
        """Start the WebSocket push channel and the fast chat poller."""
        self._websocket = Code27WebSocket(self.hass, self.client)
        self._websocket.on("music_page", self._handle_ws_music_page)
        self._websocket.on("music_source", self._handle_ws_music_source)
        self._websocket.on("music_playback", self._handle_ws_music_playback)
        self._websocket.on("music_audio_route", self._handle_ws_music_audio_route)
        self._websocket.start()

        self._chat_poll_unsub = async_track_time_interval(
            self.hass, self._async_poll_chat, CHAT_POLL_INTERVAL
        )

    def async_create_owned_task(self, coroutine: Any, name: str) -> None:
        """Keep work cancellable even when its event listener is removed."""
        if self.stopping:
            coroutine.close()
            return
        task = self.hass.async_create_task(coroutine, name=name)
        self._owned_tasks.add(task)
        task.add_done_callback(self._owned_tasks.discard)

    async def async_send_chat_reply(self, text: str, slot: int) -> None:
        """Register our output before polling can observe it as user input."""
        async with self._chat_lock:
            if self.stopping:
                return
            pending = (slot, text)
            self._pending_chat_replies.append(pending)
            # Keep the reservation on ambiguous failure: the device may have
            # accepted the write even if its acknowledgement never reached us.
            chat_id = await self.client.send_chat_text(text, slot)
            if chat_id is not None:
                self._own_chat_ids.add((slot, chat_id))
                self._pending_chat_replies.remove(pending)

    async def async_stop_realtime(self) -> None:
        self.stopping = True
        if self._chat_poll_unsub is not None:
            self._chat_poll_unsub()
            self._chat_poll_unsub = None
        tasks = set(self._owned_tasks)
        if self._poll_task is not None:
            tasks.add(self._poll_task)
        tasks.discard(asyncio.current_task())
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self.pending_correction = None
        if self._websocket is not None:
            await self._websocket.stop()
            self._websocket = None

    def _handle_ws_music_page(self, data: dict[str, Any]) -> None:
        self._handle_music_push("music_page", data)

    def _handle_ws_music_source(self, data: dict[str, Any]) -> None:
        self._handle_music_push("music_source", data)

    def _handle_ws_music_playback(self, data: dict[str, Any]) -> None:
        self._handle_music_push("music_playback", data)

    def _handle_ws_music_audio_route(self, data: dict[str, Any]) -> None:
        self._handle_music_push("music_audio_route", data)

    # -- realtime-ish: fast, dedicated chat polling ---------------------------

    async def _async_poll_chat(self, _now: Any = None) -> None:
        if not self.data or self.stopping or self._chat_lock.locked():
            return
        self._poll_task = asyncio.current_task()
        try:
            async with self._chat_lock:
                slot = self.data.current_slot.get("slot_number", 1)
                switched = slot != self._chat_active_slot
                # An already initialized empty history has no date yet;
                # include all newly appearing days, even after an outage.
                since_date = None if switched else self._chat_dates.get(slot) or ""
                try:
                    date, messages = await self.client.get_chat_history_snapshot(
                        slot, since_date, None if switched else self._chat_last_ids.get(slot)
                    )
                except Code27Error as err:
                    _LOGGER.debug("Could not fetch chat history: %s", err)
                    return
                if self.stopping or slot != self.data.current_slot.get("slot_number", 1):
                    return  # a late response must not replace another character's state
                seen = self._chat_seen.setdefault(slot, set())
                baseline = switched or slot not in self._chat_dates
                self._chat_dates[slot] = date
                self._chat_last_ids[slot] = (
                    str(messages[-1]["chat_id"])
                    if messages and messages[-1].get("chat_id") is not None else None
                )
                self._chat_active_slot = slot
                if switched:
                    self.pending_correction = None
                for message in messages:
                    chat_id = message.get("chat_id")
                    if chat_id is None:
                        continue
                    chat_id = str(chat_id)
                    if chat_id in seen:
                        continue
                    seen.add(chat_id)
                    own = (slot, chat_id) in self._own_chat_ids
                    pending = (slot, message.get("content", ""))
                    if not own and message.get("role") == "user" and pending in self._pending_chat_replies:
                        self._pending_chat_replies.remove(pending)
                        self._own_chat_ids.add((slot, chat_id))
                        own = True
                    if baseline or own:
                        continue
                    event_type = {
                        "user": EVENT_USER_MESSAGE,
                        "assistant": EVENT_ASSISTANT_MESSAGE,
                    }.get(message.get("role"))
                    if event_type:
                        self.hass.bus.async_fire(event_type, {
                            "config_entry_id": self.entry.entry_id,
                            "text": message.get("content", ""),
                            "chat_id": chat_id,
                            "slot": slot,
                            "language": self.data.system.get("ai_language"),
                            "created_at": message.get("created_at"),
                        })
                self.data.last_user_message = next(
                    (m for m in reversed(messages) if m.get("role") == "user"), {}
                )
                self.data.last_assistant_message = next(
                    (m for m in reversed(messages) if m.get("role") == "assistant"), {}
                )
                self.data.chat_messages = messages[-30:]
                self.async_update_listeners()
        finally:
            self._poll_task = None

"""The CODE27 integration."""
from __future__ import annotations

import logging

import voluptuous as vol
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_PORT, Platform
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.exceptions import ServiceValidationError
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import Code27Client
from .bridge import async_setup_bridge, async_speak_text
from .const import (
    ALARM_DAY_BITS,
    CONF_LOCAL_SECRET,
    CONF_SCAN_INTERVAL,
    CONF_USER_ID,
    DEFAULT_SCAN_INTERVAL,
    DOMAIN,
)
from .coordinator import Code27Coordinator

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [
    Platform.BINARY_SENSOR,
    Platform.BUTTON,
    Platform.LIGHT,
    Platform.MEDIA_PLAYER,
    Platform.SELECT,
    Platform.SENSOR,
    Platform.SWITCH,
    Platform.TODO,
]

SERVICE_CREATE_ALARM = "create_alarm"
SERVICE_CREATE_ALARM_SCHEMA = vol.Schema(
    {
        vol.Required("config_entry_id"): str,
        vol.Required("hour"): vol.All(int, vol.Range(min=0, max=23)),
        vol.Required("minute"): vol.All(int, vol.Range(min=0, max=59)),
        vol.Optional("label", default=""): str,
        vol.Optional("days", default=[]): vol.All(
            cv.ensure_list, [vol.In(ALARM_DAY_BITS)]
        ),
        vol.Optional("enabled", default=True): bool,
    }
)

SERVICE_UPDATE_ALARM = "update_alarm"
SERVICE_UPDATE_ALARM_SCHEMA = vol.Schema(
    {
        vol.Required("config_entry_id"): str,
        vol.Required("alarm_id"): str,
        vol.Required("hour"): vol.All(int, vol.Range(min=0, max=23)),
        vol.Required("minute"): vol.All(int, vol.Range(min=0, max=59)),
        vol.Optional("label", default=""): str,
        vol.Optional("days", default=[]): vol.All(
            cv.ensure_list, [vol.In(ALARM_DAY_BITS)]
        ),
        vol.Optional("enabled", default=True): bool,
    }
)

SERVICE_DELETE_ALARM = "delete_alarm"
SERVICE_DELETE_ALARM_SCHEMA = vol.Schema(
    {
        vol.Required("config_entry_id"): str,
        vol.Required("alarm_id"): str,
    }
)

SERVICE_SEND_CHAT_MESSAGE = "send_chat_message"
SERVICE_SEND_CHAT_MESSAGE_SCHEMA = vol.Schema(
    {
        vol.Required("config_entry_id"): str,
        vol.Required("message"): str,
        vol.Optional("slot"): int,
    }
)

SERVICE_NOTIFY = "notify"
SERVICE_NOTIFY_SCHEMA = vol.Schema(
    {
        vol.Required("config_entry_id"): str,
        vol.Optional("message"): str,
        vol.Optional("rgb_color", default=[255, 0, 0]): vol.All(
            cv.ensure_list, vol.Length(min=3, max=3), [vol.All(int, vol.Range(min=0, max=255))]
        ),
        vol.Optional("speak_text"): str,
    }
)

SERVICE_NOTIFY_CLEAR = "notify_clear"
SERVICE_NOTIFY_CLEAR_SCHEMA = vol.Schema({vol.Required("config_entry_id"): str})

SERVICE_SPEAK = "speak"
SERVICE_SPEAK_SCHEMA = vol.Schema(
    {
        vol.Required("config_entry_id"): str,
        vol.Required("text"): str,
    }
)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up CODE27 from a config entry."""
    session = async_get_clientsession(hass)
    client = Code27Client(
        session,
        entry.data[CONF_HOST],
        entry.data[CONF_PORT],
        entry.data[CONF_USER_ID],
        entry.data[CONF_LOCAL_SECRET],
    )

    scan_interval = entry.options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)
    coordinator = Code27Coordinator(hass, entry, client, scan_interval)
    await coordinator.async_config_entry_first_refresh()

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    entry.async_on_unload(entry.add_update_listener(_async_update_listener))

    coordinator.async_start_realtime()
    entry.async_on_unload(coordinator.async_stop_realtime)

    async_setup_bridge(hass, entry, coordinator)

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    def _get_coordinator(call: ServiceCall) -> Code27Coordinator:
        """Look up the target device for a service call. Raises a clean,
        user-facing ServiceValidationError (shown in the UI/automation
        trace as a normal validation failure) instead of letting a
        removed/unloaded/mistyped config_entry_id fall through as a raw
        KeyError - a bare dict lookup gave no indication of what went
        wrong or which services even take this field."""
        entry_id = call.data["config_entry_id"]
        coordinator = hass.data.get(DOMAIN, {}).get(entry_id)
        if coordinator is None:
            raise ServiceValidationError(
                f"No CODE27 device found for config_entry_id '{entry_id}' "
                "- it may have been removed, or the integration entry is "
                "not currently loaded."
            )
        return coordinator

    async def _handle_create_alarm(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        days_mask = 0
        for day in call.data.get("days", []):
            days_mask |= ALARM_DAY_BITS[day]
        await target_coordinator.client.create_alarm(
            {
                "hour": call.data["hour"],
                "minute": call.data["minute"],
                "label": call.data.get("label", ""),
                "repeat_mask": days_mask,
                "enabled": call.data.get("enabled", True),
            }
        )
        await target_coordinator.async_request_refresh()

    if not hass.services.has_service(DOMAIN, SERVICE_CREATE_ALARM):
        hass.services.async_register(
            DOMAIN,
            SERVICE_CREATE_ALARM,
            _handle_create_alarm,
            schema=SERVICE_CREATE_ALARM_SCHEMA,
        )

    async def _handle_update_alarm(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        days_mask = 0
        for day in call.data.get("days", []):
            days_mask |= ALARM_DAY_BITS[day]
        await target_coordinator.client.update_alarm(
            call.data["alarm_id"],
            {
                "hour": call.data["hour"],
                "minute": call.data["minute"],
                "label": call.data.get("label", ""),
                "repeat_mask": days_mask,
                "enabled": call.data.get("enabled", True),
            },
        )
        await target_coordinator.async_request_refresh()

    if not hass.services.has_service(DOMAIN, SERVICE_UPDATE_ALARM):
        hass.services.async_register(
            DOMAIN,
            SERVICE_UPDATE_ALARM,
            _handle_update_alarm,
            schema=SERVICE_UPDATE_ALARM_SCHEMA,
        )

    async def _handle_delete_alarm(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        await target_coordinator.client.delete_alarm(call.data["alarm_id"])
        await target_coordinator.async_request_refresh()

    if not hass.services.has_service(DOMAIN, SERVICE_DELETE_ALARM):
        hass.services.async_register(
            DOMAIN,
            SERVICE_DELETE_ALARM,
            _handle_delete_alarm,
            schema=SERVICE_DELETE_ALARM_SCHEMA,
        )

    async def _handle_send_chat_message(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        slot = call.data.get("slot") or target_coordinator.data.current_slot.get(
            "slot_number", 1
        )
        await target_coordinator.client.send_chat_text(call.data["message"], slot)

    if not hass.services.has_service(DOMAIN, SERVICE_SEND_CHAT_MESSAGE):
        hass.services.async_register(
            DOMAIN,
            SERVICE_SEND_CHAT_MESSAGE,
            _handle_send_chat_message,
            schema=SERVICE_SEND_CHAT_MESSAGE_SCHEMA,
        )

    async def _handle_notify(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        color = tuple(call.data.get("rgb_color", [255, 0, 0]))
        await target_coordinator.async_trigger_notification(call.data.get("message"), color)

        speak_text = call.data.get("speak_text")
        if speak_text:
            await async_speak_text(
                hass,
                target_coordinator.entry,
                target_coordinator,
                speak_text,
            )

    if not hass.services.has_service(DOMAIN, SERVICE_NOTIFY):
        hass.services.async_register(
            DOMAIN, SERVICE_NOTIFY, _handle_notify, schema=SERVICE_NOTIFY_SCHEMA
        )

    async def _handle_notify_clear(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        await target_coordinator.async_acknowledge_notification()

    if not hass.services.has_service(DOMAIN, SERVICE_NOTIFY_CLEAR):
        hass.services.async_register(
            DOMAIN,
            SERVICE_NOTIFY_CLEAR,
            _handle_notify_clear,
            schema=SERVICE_NOTIFY_CLEAR_SCHEMA,
        )

    async def _handle_speak(call: ServiceCall) -> None:
        target_coordinator = _get_coordinator(call)
        await async_speak_text(
            hass,
            target_coordinator.entry,
            target_coordinator,
            call.data["text"],
        )

    if not hass.services.has_service(DOMAIN, SERVICE_SPEAK):
        hass.services.async_register(
            DOMAIN, SERVICE_SPEAK, _handle_speak, schema=SERVICE_SPEAK_SCHEMA
        )

    return True


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    # Only the polling interval actually needs the coordinator recreated.
    # Everything else the options flow can change (bridge settings,
    # spellbook selection, ...) is already read fresh from entry.options
    # on every chat message, so reloading for those would just cause an
    # unnecessary interruption - and defeat "switch spellbook, no reload".
    coordinator: Code27Coordinator = hass.data[DOMAIN][entry.entry_id]
    new_interval = entry.options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL)
    if new_interval != coordinator.update_interval.total_seconds():
        await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        await hass.data[DOMAIN][entry.entry_id].async_stop_realtime()
        hass.data[DOMAIN].pop(entry.entry_id)
        if not hass.data[DOMAIN]:
            hass.services.async_remove(DOMAIN, SERVICE_CREATE_ALARM)
            hass.services.async_remove(DOMAIN, SERVICE_UPDATE_ALARM)
            hass.services.async_remove(DOMAIN, SERVICE_DELETE_ALARM)
            hass.services.async_remove(DOMAIN, SERVICE_SEND_CHAT_MESSAGE)
            hass.services.async_remove(DOMAIN, SERVICE_NOTIFY)
            hass.services.async_remove(DOMAIN, SERVICE_NOTIFY_CLEAR)
            hass.services.async_remove(DOMAIN, SERVICE_SPEAK)
    return unload_ok

"""Config flow for CODE27.

Pairing mirrors exactly what the device's own web UI does: request a
6-digit code (shown on the CODE27's physical screen), then confirm it to
receive a permanent local secret. Nothing here is invented beyond what the
device's own pairing screen already offers.
"""
from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol
from homeassistant.config_entries import ConfigEntry, ConfigFlow, ConfigFlowResult, OptionsFlow
from homeassistant.const import CONF_HOST, CONF_PORT
from homeassistant.core import callback
from homeassistant.helpers import selector
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import Code27Client, Code27ConnectionError, Code27Error
from .const import (
    CONF_BRIDGE_ACK_PHRASE,
    CONF_BRIDGE_AGENT_ID,
    CONF_BRIDGE_AI_CLEANUP_ENABLED,
    CONF_BRIDGE_AI_TASK_ENTITY_ID,
    CONF_BRIDGE_CODEWORD,
    CONF_BRIDGE_ENABLED,
    CONF_BRIDGE_ENTITY_CORRECTION_ENABLED,
    CONF_BRIDGE_RELAY_RESPONSE,
    CONF_BRIDGE_SPELLBOOK,
    CONF_BRIDGE_SPELLBOOK_MODE,
    CONF_BRIDGE_TTS_ENABLED,
    CONF_BRIDGE_VACUUM_ENABLED,
    CONF_LOCAL_SECRET,
    CONF_MACHINE_ID,
    CONF_SCAN_INTERVAL,
    CONF_USER_ID,
    DEFAULT_PORT,
    DEFAULT_SCAN_INTERVAL,
    DEFAULT_SPELLBOOK_MODE,
    DOMAIN,
    MAX_SCAN_INTERVAL,
    MIN_SCAN_INTERVAL,
    SPELLBOOK_MODE_FALLBACK,
    SPELLBOOK_MODE_STRICT,
)
from .spellbook import async_discover_spellbooks

_LOGGER = logging.getLogger(__name__)

STEP_USER_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_HOST): str,
        vol.Required(CONF_PORT, default=DEFAULT_PORT): int,
    }
)

STEP_PAIR_SCHEMA = vol.Schema({vol.Required("pairing_code"): str})


class Code27ConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle a config flow for CODE27."""

    VERSION = 1

    def __init__(self) -> None:
        self._host: str | None = None
        self._port: int = DEFAULT_PORT
        self._client: Code27Client | None = None
        self._challenge_id: str | None = None
        self._reauth_entry: ConfigEntry | None = None
        self._paired_credentials: tuple[str, str] | None = None

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            self._host = user_input[CONF_HOST]
            self._port = user_input[CONF_PORT]
            session = async_get_clientsession(self.hass)
            self._client = Code27Client(session, self._host, self._port)
            try:
                await self._client.bootstrap()
            except Code27ConnectionError:
                errors["base"] = "cannot_connect"
            except Code27Error:
                errors["base"] = "unknown"
            else:
                return await self._async_request_pairing_code()

        return self.async_show_form(
            step_id="user", data_schema=STEP_USER_SCHEMA, errors=errors
        )

    async def _async_request_pairing_code(self) -> ConfigFlowResult:
        assert self._client is not None
        self._paired_credentials = None
        try:
            self._challenge_id = await self._client.pair_request()
        except Code27Error as err:
            _LOGGER.debug("Pairing request failed: %s", err)
            return self.async_show_form(
                step_id="user",
                data_schema=STEP_USER_SCHEMA,
                errors={"base": "pairing_request_failed"},
            )
        return await self.async_step_pair()

    async def async_step_pair(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        errors: dict[str, str] = {}
        assert self._client is not None

        if user_input is not None:
            code = user_input["pairing_code"].strip()
            try:
                user_id, secret = await self._client.pair_confirm(
                    code, self._challenge_id or ""
                )
            except Code27Error as err:
                code_str = getattr(err, "code", None) or str(err)
                if code_str in ("PAIRING_CODE_EXPIRED", "PAIRING_CODE_USED"):
                    # The code is burned; ask the device to show a new one.
                    return await self._async_request_pairing_code()
                errors["base"] = "invalid_pairing_code"
            else:
                self._paired_credentials = (user_id, secret)
                return await self.async_step_verify()

        return self.async_show_form(
            step_id="pair",
            data_schema=STEP_PAIR_SCHEMA,
            errors=errors,
            description_placeholders={"host": self._host or ""},
        )

    async def async_step_verify(self, user_input=None) -> ConfigFlowResult:
        """Retry the signed identity read without consuming the pairing code again."""
        assert self._client is not None and self._paired_credentials is not None
        try:
            system = await self._client.get_system()
        except Code27ConnectionError:
            error = "cannot_connect"
        except Code27Error:
            error = "unknown"
        else:
            return await self._async_finish_pairing(system)
        return self.async_show_form(
            step_id="verify", data_schema=vol.Schema({}), errors={"base": error}
        )

    async def _async_finish_pairing(self, system: dict[str, Any]) -> ConfigFlowResult:
        assert self._paired_credentials is not None
        user_id, secret = self._paired_credentials
        machine_id = system.get("machine_id") or user_id
        if not isinstance(machine_id, str) or not machine_id:
            return self.async_abort(reason="invalid_identity")

        if self._reauth_entry is not None:
            expected = self._reauth_entry.data.get(CONF_MACHINE_ID) or self._reauth_entry.unique_id
            if not expected or machine_id != expected:
                return self.async_abort(reason="wrong_device")
            self.hass.config_entries.async_update_entry(
                self._reauth_entry,
                data={
                    **self._reauth_entry.data,
                    CONF_USER_ID: user_id,
                    CONF_LOCAL_SECRET: secret,
                },
            )
            await self.hass.config_entries.async_reload(
                self._reauth_entry.entry_id
            )
            return self.async_abort(reason="reauth_successful")

        await self.async_set_unique_id(machine_id)
        self._abort_if_unique_id_configured()

        return self.async_create_entry(
            title=f"CODE27 ({self._host})",
            data={
                CONF_HOST: self._host,
                CONF_PORT: self._port,
                CONF_USER_ID: user_id,
                CONF_LOCAL_SECRET: secret,
                CONF_MACHINE_ID: machine_id,
            },
        )

    async def async_step_reauth(
        self, entry_data: dict[str, Any]
    ) -> ConfigFlowResult:
        self._reauth_entry = self.hass.config_entries.async_get_entry(
            self.context["entry_id"]
        )
        self._host = entry_data[CONF_HOST]
        self._port = entry_data.get(CONF_PORT, DEFAULT_PORT)
        session = async_get_clientsession(self.hass)
        self._client = Code27Client(session, self._host, self._port)
        return await self._async_request_pairing_code()

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: ConfigEntry) -> OptionsFlow:
        return Code27OptionsFlow(config_entry)


class Code27OptionsFlow(OptionsFlow):
    """Options for CODE27: polling interval."""

    def __init__(self, config_entry: ConfigEntry) -> None:
        self._config_entry = config_entry

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        if user_input is not None:
            return self.async_create_entry(data=user_input)

        options = self._config_entry.options
        spellbook_choices = await async_discover_spellbooks(self.hass)
        none_label = (
            "— Kein Spellbook —"
            if (self.hass.config.language or "en").lower().startswith("de")
            else "— No spellbook —"
        )
        spellbook_options = [
            selector.SelectOptionDict(value="", label=none_label)
        ] + [
            selector.SelectOptionDict(value=book_id, label=name)
            for book_id, name in spellbook_choices
        ]
        schema = vol.Schema(
            {
                vol.Required(
                    CONF_SCAN_INTERVAL,
                    default=options.get(CONF_SCAN_INTERVAL, DEFAULT_SCAN_INTERVAL),
                ): vol.All(int, vol.Range(min=MIN_SCAN_INTERVAL, max=MAX_SCAN_INTERVAL)),
                vol.Required(
                    CONF_BRIDGE_ENABLED,
                    default=options.get(CONF_BRIDGE_ENABLED, False),
                ): bool,
                vol.Optional(
                    CONF_BRIDGE_CODEWORD,
                    description={"suggested_value": options.get(CONF_BRIDGE_CODEWORD, "")},
                ): str,
                vol.Optional(
                    CONF_BRIDGE_SPELLBOOK,
                    default=options.get(CONF_BRIDGE_SPELLBOOK, ""),
                ): selector.SelectSelector(
                    selector.SelectSelectorConfig(
                        options=spellbook_options,
                        mode=selector.SelectSelectorMode.DROPDOWN,
                    )
                ),
                vol.Optional(
                    CONF_BRIDGE_SPELLBOOK_MODE,
                    default=options.get(CONF_BRIDGE_SPELLBOOK_MODE, DEFAULT_SPELLBOOK_MODE),
                ): selector.SelectSelector(
                    selector.SelectSelectorConfig(
                        options=[SPELLBOOK_MODE_FALLBACK, SPELLBOOK_MODE_STRICT],
                        mode=selector.SelectSelectorMode.DROPDOWN,
                        translation_key="bridge_spellbook_mode",
                    )
                ),
                vol.Required(
                    CONF_BRIDGE_ENTITY_CORRECTION_ENABLED,
                    default=options.get(CONF_BRIDGE_ENTITY_CORRECTION_ENABLED, False),
                ): bool,
                vol.Optional(
                    CONF_BRIDGE_ACK_PHRASE,
                    description={"suggested_value": options.get(CONF_BRIDGE_ACK_PHRASE, "")},
                ): str,
                vol.Optional(
                    CONF_BRIDGE_AGENT_ID,
                    description={"suggested_value": options.get(CONF_BRIDGE_AGENT_ID)},
                ): selector.ConversationAgentSelector(
                    selector.ConversationAgentSelectorConfig()
                ),
                vol.Required(
                    CONF_BRIDGE_RELAY_RESPONSE,
                    default=options.get(CONF_BRIDGE_RELAY_RESPONSE, False),
                ): bool,
                vol.Required(
                    CONF_BRIDGE_TTS_ENABLED,
                    default=options.get(CONF_BRIDGE_TTS_ENABLED, False),
                ): bool,
                vol.Required(
                    CONF_BRIDGE_AI_CLEANUP_ENABLED,
                    default=options.get(CONF_BRIDGE_AI_CLEANUP_ENABLED, False),
                ): bool,
                vol.Optional(
                    CONF_BRIDGE_AI_TASK_ENTITY_ID,
                    description={
                        "suggested_value": options.get(CONF_BRIDGE_AI_TASK_ENTITY_ID)
                    },
                ): selector.EntitySelector(
                    selector.EntitySelectorConfig(domain="ai_task")
                ),
                vol.Required(
                    CONF_BRIDGE_VACUUM_ENABLED,
                    default=options.get(CONF_BRIDGE_VACUUM_ENABLED, False),
                ): bool,
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema)
